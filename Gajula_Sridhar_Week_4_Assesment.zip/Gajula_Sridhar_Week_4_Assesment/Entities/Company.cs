﻿using System;
using System.Collections.Generic;

namespace Gajula_Sridhar_Week_4_Assesment.Entities;

public partial class Company
{
    public int CompanyId { get; set; }

    public string Name { get; set; } = null!;

    public string City { get; set; } = null!;

    public string Address { get; set; } = null!;
}
