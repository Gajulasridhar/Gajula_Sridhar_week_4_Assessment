﻿using Gajula_Sridhar_Week_4_Assesment.Entities;
using Microsoft.AspNetCore.Mvc;

namespace Gajula_Sridhar_Week_4_Assesment.Controllers
{
    public class StudentController : Controller
    {
        private readonly SqlAssesmentContext sqlAssesmentContext;
        public StudentController()
        {
            sqlAssesmentContext = new SqlAssesmentContext();
        }
        public IActionResult Index()
        {
            var students = sqlAssesmentContext.Students;
            return View(students);
        }
        [HttpGet]
        public IActionResult Create()
        {

            return View();
        }
        [HttpPost]
        public IActionResult Create(Student student)
        {
            if (ModelState.IsValid)
            {
                sqlAssesmentContext.Students.Add(student);
                sqlAssesmentContext.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {

                return View();
            }
        }

        public IActionResult Delete(int id)
        {
            var student = sqlAssesmentContext.Students.SingleOrDefault(p => p.StudentId == id);
            return View(student);
        }
        [HttpPost]
        public IActionResult Delete(Student student)
        {

            sqlAssesmentContext.Students.Remove(student);
            sqlAssesmentContext.SaveChanges();
            return RedirectToAction("Index");

        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var student = sqlAssesmentContext.Students.SingleOrDefault(p => p.StudentId == id);
            return View(student);
        }
        [HttpPost]
        public IActionResult Edit(Student student)
        {
            if (ModelState.IsValid)
            {
                sqlAssesmentContext.Students.Update(student);
                sqlAssesmentContext.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {

                return View();
            }
        }

        public IActionResult Details(int id)
        {
            var student = sqlAssesmentContext.Students.SingleOrDefault(p => p.StudentId == id);
            return View(student);
        }


    }
}
