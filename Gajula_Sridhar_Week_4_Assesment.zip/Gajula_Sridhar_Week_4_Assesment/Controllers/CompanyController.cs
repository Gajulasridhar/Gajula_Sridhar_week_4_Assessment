﻿using Gajula_Sridhar_Week_4_Assesment.Entities;
using Microsoft.AspNetCore.Mvc;

namespace Gajula_Sridhar_Week_4_Assesment.Controllers
{
    public class CompanyController : Controller
    {
        private readonly SqlAssesmentContext sqlAssesmentContext;
        public CompanyController()
        {
            sqlAssesmentContext = new SqlAssesmentContext();
        }
        public IActionResult Index()
        {
            var companies=sqlAssesmentContext.Companies;
            return View(companies);
        }
        [HttpGet]
        public IActionResult Create()
        {

            return View();
        }
        [HttpPost]
        public IActionResult Create(Company company)
        {
            if (ModelState.IsValid)
            {
                sqlAssesmentContext.Companies.Add(company);
                sqlAssesmentContext.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {

                return View();
            }
        }
    }
}
